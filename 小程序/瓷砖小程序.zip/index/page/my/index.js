var sliderWidth = 96 // 需要设置slider的宽度，用于计算中间位置

Page({
  data: {
    list: [
      { alphabet: 'Top', datas: [] },
      { alphabet: 'A', datas: ['安阳', '安庆', '安康','安顺'] },
      { alphabet: 'B', datas: ['北京', '保定', '白城'] },
      { alphabet: 'C', datas: ['长沙', '成都', '重庆', '长春', '蔡家' ,'坡长', '武澄' ,'城成县'] },
      { alphabet: 'D', datas: ['德阳市'] },
      { alphabet: 'E', datas: ['峨眉山市'] },
      { alphabet: 'F', datas: ['广州', '福州市', '阜康','涪陵','阜南','抚宁','阜宁','富宁','富平','福清','浮山','抚顺','富顺','抚松','扶绥','富县','阜新'  ,'阜阳','富阳','富源','富蕴'] },
      { alphabet: 'G', datas: ['广州'] },
      { alphabet: 'H', datas: ['杭州','哈巴河' , '哈尔滨'  ,'海安' , '海北'  ,'海城' , '海东' , '海丰' , '海口'] },
      { alphabet: 'I', datas: ['上海', '深圳', '苏州'] },
      { alphabet: 'J', datas: ['上海', '深圳', '苏州'] },
      { alphabet: 'K', datas: ['上海', '深圳', '苏州'] },
      { alphabet: 'L', datas: ['上海', '深圳', '苏州'] },
      { alphabet: 'N', datas: ['南京'] },
      { alphabet: 'S', datas: ['上海', '深圳', '苏州'] },
      { alphabet: 'W', datas: ['武汉'] },
      { alphabet: 'X', datas: ['西宁', '西海', '宣城' , '宣汉' , '宣威'  ,'许昌'  ,'浚县' , '旬阳' , '旬邑',  '溆浦',  '徐闻' , '盱眙' , '叙永' , '徐州' ] },
      { alphabet: 'Y', datas: ['武汉'] },
      { alphabet: 'Z', datas: ['资阳'] },
    ],
    alpha: '',
    windowHeight: '',
    tabs: [" ", "城市列表"],
    activeIndex: 0,
    sliderOffset: 0,
    sliderLeft: 0,
    userInfo: {}
  },
  tabClick: function (e) {
    this.setData({
      sliderOffset: e.currentTarget.offsetLeft,
      activeIndex: e.currentTarget.id
    })
  },
  handlerAlphaTap(e) {
    let { ap } = e.target.dataset
    this.setData({ alpha: ap })
  },
  handlerMove(e) {
    let { list } = this.data
    let moveY = e.touches[0].clientY
    let rY = moveY - this.offsetTop
    if (rY >= 0) {
      let index = Math.ceil((rY - this.apHeight) / this.apHeight)
      if (0 <= index < list.length) {
        let nonwAp = list[index]
        nonwAp && this.setData({ alpha: nonwAp.alphabet })
      }
    }
  }
})


