// page/details/details.js
Page({
  
})