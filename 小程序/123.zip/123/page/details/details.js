// page/details/details.js
Page({
  data:{
    goods: {
      id: 1,
      image: '/image/uuu1.jpg',
      title: '泉州大白网络科技',
      price: 88,
      stock: '200',
      detail: '泉州大白网络科技是一家互联网创意机构，致力于微信小程序，微信公众号营销推广，淘客建站及其他电商系统的研发与运营。我们以丰富的研发经验和快速的产品创新能力，为客户提供完善的售前售后服务！',
      parameter: '125g/个',
      service: '不支持退货'
    },
    num: 1,
    totalNum: 0,
    hasCarts: false,
    curIndex: 0,
    show: false,
    scaleCart: false
  },
   teltoUs:function(){
	   wx.makePhoneCall({
			phoneNumber: '18664369878' //仅为示例，并非真实的电话号码
		})
   }	
})