

window.onload=function () {
    // 完美煮意和五品烩晚餐
    var swiper1 = new Swiper('.swiper-container1', {
        slidesPerView: 1,
        pagination: {
            el: '.ul',
            bulletElement : 'li',
            bulletClass : 'li',
            bulletActiveClass: 'active',
        },
    });
    // 最多食谱
    var swiper2 = new Swiper('.swiper-container2', {
        slidesPerView: 'auto',
        spaceBetween: '4.6%',
        freeMode: true
    });

};
